﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppStudio.Data
{
    public class TwitterSearchResult
    {
        public TwitterTimeLineItem[] statuses { get; set; }
    }
}
